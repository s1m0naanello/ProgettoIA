Bloomin Garden's -> progetto realizzato da Anello Simona (209393) e Rebecca D'Apa (213695).
Per avviare il gioco -> Application -> Run As -> Java Application
Digitare "ia" per far giocare l'ia, qualsiasi altra cosa per far giocare l'utente.