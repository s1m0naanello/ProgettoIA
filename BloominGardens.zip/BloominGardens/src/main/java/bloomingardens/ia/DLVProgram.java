package bloomingardens.ia;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

import bloomingardens.model.Game;

public class DLVProgram {
	
	private String leggiRegole() {
        String programma = null;
        try {
        programma = new String(Files.readAllBytes(new File(DLVProgram.class.getClassLoader().getResource("dlv/programma.txt").getFile()).toPath()), StandardCharsets.UTF_8);
        } catch ( final IOException e ) {e.printStackTrace();}
        return programma;
    }
	
	private String prossimiFiori(String[] prossimiFiori) {
		StringBuilder fiori = new StringBuilder();
		for(int i=0; i<3; i++) {
			fiori.append("prossimoFiore("+prossimiFiori[i].toLowerCase()+","+i+").\n");
		}
		return fiori.toString();
	}
	
	private String generaFatti(String[][] mappa) {
		StringBuilder fatti = new StringBuilder();
		int idFiore = 10;
		for(int i=0; i<9; i++) {
			for(int j=0; j<9; j++) {
				idFiore++;
				if(!mappa[i][j].equals("."))
					fatti.append("fiore("+idFiore+","+mappa[i][j].toLowerCase()+","+i+","+j+","+Game.getInstance().getPunteggio(mappa[i][j])+").\n");
				else
					fatti.append("fiore("+idFiore+",vuoto,"+i+","+j+","+0+").\n");
			}
		}
		return fatti.toString();
	}
	
	public void calcolaAS(String[][] mappa, String[] prossimiFiori, Process processo) {
		StringBuilder programma = new StringBuilder();
		//out -> input del processo per dlv
        try (OutputStream out = processo.getOutputStream(); OutputStreamWriter ow = new OutputStreamWriter(out)) {
        	programma.append(leggiRegole()); //Leggo le regole da passare a dlv
            programma.append( "\n" );
            programma.append(generaFatti(mappa)); //Converto la mappa in fatti per dlv
            programma.append(prossimiFiori(prossimiFiori)); //Converto i prossimi fiori in fatti per dlv
            String programmaFinale = programma.toString();
            
            ow.write(programmaFinale);
            ow.close();
        } catch (final IOException e) {e.printStackTrace();}
    }

}
