package bloomingardens.ia;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import bloomingardens.controller.GameController;

public class DLVController {
	
	GameController gameController;
	Process processoDLV;
	BufferedReader outputProcesso;
	File dlv;
	
	public DLVController(GameController gameController) {
        this.gameController = gameController;
        try {
        	getDLV();
        } catch ( final Exception e ) {
            e.printStackTrace();
        }
    }

	private void getDLV() {
		dlv = new File( getClass().getResource("/dlv/dlv2.exe").getPath() );		
	}
	
	public Process start() {
		processoDLV = null;
		final Runtime rt = Runtime.getRuntime();
		final String[] comandi = { dlv.getAbsolutePath(), "--stdin", "--no-facts", "--filter=fioreScelto/6"};
		try {
			processoDLV = rt.exec(comandi);
		} catch (IOException e) {e.printStackTrace();}
		
		outputProcesso = new BufferedReader(new InputStreamReader(processoDLV.getInputStream(), Charset.defaultCharset()));
		
		return processoDLV;
	}
	
	//Leggi l'answer set
	public String[] getAnswerSet() {
		Stream<String> output = outputProcesso.lines();
		StringBuilder sb = new StringBuilder();
		output.forEach(sb::append); //Per ogni elemento di output fai append su sb
		try {
			outputProcesso.close();
		} catch (IOException e) {e.printStackTrace();}
		String answerSet = sb.toString();
		
		//System.out.println(answerSet);
		String[] asFinale = new String[6];
		
		Pattern p = Pattern.compile("fioreScelto\\((\\d+),([a-z]),(\\d),(\\d),(\\d),(\\d)\\)");
		Matcher m = p.matcher(answerSet);
		while (m.find()) {
			asFinale[0] = m.group(1);
			asFinale[1] = m.group(2);
			asFinale[2] = m.group(3);
			asFinale[3] = m.group(4);
			asFinale[4] = m.group(5);
			asFinale[5] = m.group(6);
		}
		
		return asFinale;
	}
	
}
