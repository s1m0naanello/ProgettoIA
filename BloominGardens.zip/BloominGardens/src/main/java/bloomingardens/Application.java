package bloomingardens;

import bloomingardens.controller.GameController;

public class Application {

	public static void main(String[] args) {
		System.out.println("Bloomin' Gardens");
		GameController gameController = new GameController();
		gameController.start();
	}

}
