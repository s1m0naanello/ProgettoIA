package bloomingardens.model;


public class Game {
	
	private String[][] mappa = new String[9][9];
	private String[] fiori = {"A", "B", "C", "D", "E"}; //Punteggio per ogni fiore pos+1 {1, 2, 3, 4, 5} 
	private String[] prossimiFiori = new String[3];
	private int score = 0;
	
	private static Game game = null;
	
	public static Game getInstance() {
		if(game == null)
			game = new Game();
		return game;
	}
	
	public Game() {
		//Creo la mappa
		for(int i=0; i<9; i++) {
			for(int j=0; j<9; j++) {
				mappa[i][j] = ".";
			}
		}
		//Ad inizio partita pianto 3 fiori random
		this.prossimiFiori = generaFiori();
		//Li pianto in un punto random della mappa
		piantaFioriGenerati(this.prossimiFiori);
	}
	
	public String[] generaFiori() {
		for(int i=0; i<3; i++) {
			int rand = (int)(Math.random()*5);
			this.prossimiFiori[i] = fiori[rand];
		}
		return this.prossimiFiori;
	}
	
	public void piantaFioriGenerati(String[] fiori) {
		int[] righe = new int[3], colonne = new int[3];
		for(int i=0; i<fiori.length; i++) {
			int randr=(int)(Math.random()*9), randc=(int)(Math.random()*9);
			while(!mappa[randr][randc].equals(".")) {
				randr = (int)(Math.random()*9);
				randc = (int)(Math.random()*9);
			}
			mappa[randr][randc] = fiori[i];
			righe[i] = randr;
			colonne[i] = randc;
		}
		controllaFioriGenerati(fiori, righe, colonne); //Controllo se i 3 fiori random appena piantati eliminano qualcosa
	}
	
	public void controllaFioriGenerati(String[] fiori, int[] righe, int[] colonne) {
		boolean[] righeColonneEliminate = new boolean[3], diagonaliEliminate = new boolean[3];
		for(int i=0; i<3; i++) {
			righeColonneEliminate[i] = eliminaRigaColonna(righe[i],colonne[i],fiori[i]);
			diagonaliEliminate[i] = eliminaDiagonale(righe[i],colonne[i],fiori[i]);
		}
		for(int i=0; i<3; i++) {
			if(righeColonneEliminate[i] || diagonaliEliminate[i] ) {
				mappa[righe[i]][colonne[i]] = ".";
				updateScore(fiori[i], 1);
			}
		}
	}
	
	//Controlla se la casella selezionata dal giocatore è valida
	public boolean selezionaCasellaValida(String rstring, String cstring, boolean pianta) {
		int r=-1, c=-1;
		for(int i=0; i<9; i++) {
			if(rstring.equals(Integer.toString(i)))
				r = Integer.parseInt(rstring);
			if(cstring.equals(Integer.toString(i)))
				c = Integer.parseInt(cstring);
		}
		if(r==-1 || c==-1) //Se l'utente ha inserito un carattere che non sia un numero
			return false;
		if(!pianta && (r>=0 && r<9) && (c>=0 && c<9) && (!mappa[r][c].equals("."))) //Quando seleziona il fiore
			return true;
		else if(pianta && (r>=0 && r<9) && (c>=0 && c<9) && (mappa[r][c].equals("."))) //Quando pianta il fiore
			return true;
		return false; //Casella non valida
	}
	
	//Prende il fiore selezionato
	public String selezionaFiore(int r, int c) {
		String fiore = mappa[r][c];
		mappa[r][c]=".";
		return fiore;
	}
	
	public void piantaFiore(int r, int c, String fiore) {
		mappa[r][c] = fiore;
		boolean rigaColonnaEliminata = eliminaRigaColonna(r,c,fiore);
		boolean diagonaleEliminata = eliminaDiagonale(r,c,fiore);
		if(rigaColonnaEliminata  || diagonaleEliminata) { //Elimino il fiore appena piantato
			mappa[r][c] = ".";
			updateScore(fiore, 1);
		}
		piantaFioriGenerati(this.prossimiFiori);
	}
	
	private boolean eliminaRigaColonna(int r, int c, String fiore) { //Controllo a partire dal fiore che ho appena piantato
		boolean eliminata = false;
		int contaFioriUgualiDestra=0, contaFioriUgualiSinistra=0, contaFioriUguali=1;
		for(int i=r, j=c; (j+1)<9; j++) { //Riga a destra
			if(mappa[i][j].equals(fiore) && mappa[i][j+1].equals(fiore))
				contaFioriUgualiDestra++;
		}
		for(int i=r, j=c; (j-1)>=0; j--) { //Riga a sinistra
			if(mappa[i][j].equals(fiore) && mappa[i][j-1].equals(fiore))
				contaFioriUgualiSinistra++;
		}
		contaFioriUguali += contaFioriUgualiDestra;
		contaFioriUguali += contaFioriUgualiSinistra;
		if(contaFioriUguali>=5) {
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiDestra; j++, conta++) {
				mappa[i][j] = ".";
			}
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiSinistra; j--, conta++) {
				mappa[i][j] = ".";
			}
			eliminata = true;
			updateScore(fiore, contaFioriUguali-1);
		}
		mappa[r][c] = fiore;
		contaFioriUguali=1;
		int contaFioriUgualiSu=0, contaFioriUgualiGiu=0;
		for(int i=r, j=c; (i+1)<9; i++) { //Colonna giù
			if(mappa[i][j].equals(fiore) && mappa[i+1][j].equals(fiore))
				contaFioriUgualiGiu++;
		}
		for(int i=r, j=c; (i-1)>=0; i--) { //Colonna su
			if(mappa[i][j].equals(fiore) && mappa[i-1][j].equals(fiore))
				contaFioriUgualiSu++;
		}
		contaFioriUguali += contaFioriUgualiGiu;
		contaFioriUguali += contaFioriUgualiSu;
		if(contaFioriUguali>=5) {
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiGiu; i++, conta++) {
				mappa[i][j] = ".";
			}
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiSu; i--, conta++) {
				mappa[i][j] = ".";
			}
			eliminata = true;
			updateScore(fiore, contaFioriUguali-1);
		}
		mappa[r][c] = fiore;
		return eliminata;
	}
	
	private boolean eliminaDiagonale(int r, int c, String fiore) {
		boolean eliminata = false;
		int contaFioriUgualiScendere=0, contaFioriUgualiSalire=0, contaFioriUguali=1;
		for(int i=r, j=c; (i+1)<9 && (j+1)<9; i++, j++) { //Diagonale destra a scendere
			if(mappa[i][j].equals(fiore) && mappa[i+1][j+1].equals(fiore))
				contaFioriUgualiScendere++; //Ho fiori consecutivi uguali.
		}
		for(int i=r, j=c; (i-1)>=0 && (j-1)>=0; i--, j--) { //Diagonale destra a salire
			if(mappa[i][j].equals(fiore) && mappa[i-1][j-1].equals(fiore))
				contaFioriUgualiSalire++;
		}
		contaFioriUguali += contaFioriUgualiScendere;
		contaFioriUguali += contaFioriUgualiSalire;
		if(contaFioriUguali>=5) {
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiScendere; i++, j++, conta++) { //Diagonale a scendere
				mappa[i][j] = ".";
			}
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiSalire; i--, j--, conta++) { //Diagonale a salire
				mappa[i][j] = ".";
			}
			eliminata = true;
			updateScore(fiore, contaFioriUguali-1);
		}
		mappa[r][c] = fiore;
		contaFioriUgualiScendere=0;
		contaFioriUgualiSalire=0;
		contaFioriUguali=1;
		for(int i=r, j=c; (i+1)<9 && (j-1)>=0; i++, j--) { //Diagonale sinistra a scendere
			if(mappa[i][j].equals(fiore) && mappa[i+1][j-1].equals(fiore))
				contaFioriUgualiScendere++; //Ho fiori consecutivi uguali.
		}
		for(int i=r, j=c; (i-1)>=0 && (j+1)<9; i--, j++) { //Diagonale sinistra a salire
			if(mappa[i][j].equals(fiore) && mappa[i-1][j+1].equals(fiore))
				contaFioriUgualiSalire++;
		}
		contaFioriUguali += contaFioriUgualiScendere;
		contaFioriUguali += contaFioriUgualiSalire;
		if(contaFioriUguali>=5) {
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiScendere; i++, j--, conta++) { //Diagonale a scendere
				mappa[i][j] = ".";
			}
			for(int i=r, j=c, conta=0; conta<=contaFioriUgualiSalire; i--, j++, conta++) { //Diagonale a salire
				mappa[i][j] = ".";
			}
			eliminata = true;
			updateScore(fiore, contaFioriUguali-1);
		}
		mappa[r][c] = fiore;
		return eliminata;
	}
	
	public boolean controllaGameOver() { //Game Over quando ho meno di 3 caselle libere
		int caselleLibere = 0;
		for(int i=0; i<9; i++) {
			for(int j=0; j<9; j++) {
				if (mappa[i][j].equals(".")) {
					caselleLibere++;
					if(caselleLibere>=3) return false;
				}
			}
		}
		return true;
	}
	
	public int getScore() {
		return this.score;
	}
	
	public int getPunteggio(String fiore) {
		int punteggio = 0;
		for(int i=0; i<5; i++) {
			if(fiori[i].equals(fiore))
				punteggio = (i+1);
		}
		return punteggio;
	}
	
	private void updateScore(String fiore, int quantita) {
		for(int i=0; i<5; i++) {
			if(fiori[i].equals(fiore))
				this.score+= (i+1)*quantita;
		}
	}
	
	public void stampa() {
		System.out.print("  ");
		for(int i=0; i<9; i++)
			System.out.print(i+" ");
		System.out.println();
		for(int i=0; i<9; i++) {
			System.out.print(i+" ");
			for(int j=0; j<9; j++) {
				System.out.print(mappa[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public String[][] getMappa(){return mappa;}
	
	public String[] getProssimiFiori() {return prossimiFiori;}
}