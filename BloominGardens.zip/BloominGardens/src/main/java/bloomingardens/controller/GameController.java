package bloomingardens.controller;

import java.io.*;

import bloomingardens.ia.DLVController;
import bloomingardens.ia.DLVProgram;
import bloomingardens.model.Game;

public class GameController {
	
	private DLVController dlvController;
	private DLVProgram programmaDLV;
	public boolean gameOver = false;
	public boolean iaON = false;
	
	public void start() {
		System.out.print("Digita IA per attivare l'IA. Digita qualsiasi altra cosa per giocare.");
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		try {
			String statoIA = stdin.readLine();
			if (statoIA.equals("IA") || statoIA.equals("ia")) 
				iaON = true;
		} catch (IOException e) { e.printStackTrace(); }
		while(!gameOver) {
			play();
			if(!iaON) {
				String fiore = prendiFiore();
				piantaFiore(fiore);
			}
			else {
				dlvController = new DLVController(this);
				programmaDLV = new DLVProgram();
				playIA();
			}
		}
		play();
	}
	
	private void play() {
		Game.getInstance().stampa();
		if(!gameOver) {
			String[] prossimiFiori = Game.getInstance().generaFiori();
			System.out.print("Prossimi Fiori: ");
			for(String f: prossimiFiori)
				System.out.print(f+" ");
			System.out.println();
		}
		System.out.println("Punteggio: "+ Game.getInstance().getScore() + "\n");
	}
	
	private void playIA() {
		Process processoDLV = dlvController.start();
		String[][] mappa = Game.getInstance().getMappa();
		programmaDLV.calcolaAS(mappa, Game.getInstance().getProssimiFiori(), processoDLV);
		String[] mossa = dlvController.getAnswerSet(); 
		Game.getInstance().selezionaFiore(Integer.parseInt(mossa[2]), Integer.parseInt(mossa[3]));
		Game.getInstance().piantaFiore(Integer.parseInt(mossa[4]), Integer.parseInt(mossa[5]), mossa[1].toUpperCase());
		System.out.println("Fiore "+mossa[1].toUpperCase()+" in ("+Integer.parseInt(mossa[2])+","+Integer.parseInt(mossa[3])+"). Spostato in ("+Integer.parseInt(mossa[4])+","+Integer.parseInt(mossa[5])+").");
		if(Game.getInstance().controllaGameOver()) {
			gameOver = true;
			System.out.println("Game Over!");
		}
	}

	private String prendiFiore() {
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		String riga="", colonna="", fioreSelezionato="";
		int rigaSelezionata=-1, colonnaSelezionata=-1;
		while(rigaSelezionata==-1 || colonnaSelezionata==-1) {
			System.out.print("Seleziona un fiore per spostarlo. \nInserisci la riga: ");
			try {
				riga = stdin.readLine();
			} catch (IOException e) { e.printStackTrace(); }
			System.out.print("Inserisci la colonna: ");
			try {
				colonna = stdin.readLine();;
			} catch (IOException e) { e.printStackTrace(); }
			if(!Game.getInstance().selezionaCasellaValida(riga, colonna, false)) {
				System.out.println("Casella non valida. Riprova.");
			}
			else {
				rigaSelezionata = Integer.parseInt(riga);
				colonnaSelezionata = Integer.parseInt(colonna);
				fioreSelezionato = Game.getInstance().selezionaFiore(rigaSelezionata, colonnaSelezionata);
			}
		}
		return fioreSelezionato;
	}
	
	private void piantaFiore(String fioreSelezionato) {
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		String riga="", colonna="";
		int rigaSelezionata=-1, colonnaSelezionata=-1;
		while(rigaSelezionata==-1 || colonnaSelezionata==-1) {
			System.out.print("Pianta il fiore " + fioreSelezionato + ".\nInserisci la riga: ");
			try {
				riga = stdin.readLine();
			} catch (IOException e) { e.printStackTrace(); }
			System.out.print("Inserisci la colonna: ");
			try {
				colonna = stdin.readLine();;
			} catch (IOException e) { e.printStackTrace(); }
			if(!Game.getInstance().selezionaCasellaValida(riga, colonna, true)) {
				System.out.println("Casella non valida. Riprova.");
			}
			else {
				rigaSelezionata = Integer.parseInt(riga);
				colonnaSelezionata = Integer.parseInt(colonna);
				Game.getInstance().piantaFiore(rigaSelezionata, colonnaSelezionata, fioreSelezionato);
				if(Game.getInstance().controllaGameOver()) {
					gameOver = true;
					System.out.println("Game Over!");
				}
			}
		}
	}
}